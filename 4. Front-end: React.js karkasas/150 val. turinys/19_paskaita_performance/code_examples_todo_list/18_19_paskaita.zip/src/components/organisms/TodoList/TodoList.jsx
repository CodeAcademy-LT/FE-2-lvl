import { useState, useEffect, useRef } from 'react';
import FilterItem from '../../atoms/FilterItem';
import Input from '../../atoms/Input/Input';
import TodoItem from '../../atoms/TodoItem';
import Button from '../../atoms/Button';
import {
  StyledTodoList,
  StyledTodoListHeader,
  StyledTodoListSearchWrapper,
  StyledTodoListFiltershWrapper,
  StyledTodoListItemWrapper,
  StyledTodoListButtonWrapper,
} from './TodoList.style';

const filters = [
  {
    title: 'All',
  },
  {
    title: 'Completed',
  },
  {
    title: 'Not Completed',
  },
];

const TodoList = () => {
  const [todos, setTodos] = useState(null);
  const [displyedTodos, setdisplyedTodos] = useState(null);
  const [filterBy, setFilterBy] = useState('All');
  const [loading, setLoading] = useState(true);

  const initialMount = useRef(true);
  const inputParentRef = useRef();

  useEffect(() => {
    if (initialMount.current) {
      (async () => {
        const data = await (
          await fetch('https://jsonplaceholder.typicode.com/todos')
        ).json();

        setLoading(false);
        setTodos(data.slice(0, 10));
        setdisplyedTodos(data.slice(0, 10));

        initialMount.current = false;
      })();
    } else {
      if (filterBy === 'Completed') {
        setdisplyedTodos(todos.filter((todo) => todo.completed));
      } else if (filterBy === 'Not Completed') {
        setdisplyedTodos(todos.filter((todo) => !todo.completed));
      } else {
        setdisplyedTodos(todos);
      }
    }
  }, [filterBy]);

  const handleSeach = (input) => {
    if (filterBy === 'Completed') {
      setdisplyedTodos(
        todos.filter((todo) => todo.title.includes(input) && todo.completed)
      );
    } else if (filterBy === 'Not Completed') {
      setdisplyedTodos(
        todos.filter((todo) => todo.title.includes(input) && !todo.completed)
      );
    } else {
      setdisplyedTodos(todos.filter((todo) => todo.title.includes(input)));
    }
  };

  const handleReset = () => {
    setdisplyedTodos(todos);
    setFilterBy('All');

    inputParentRef.current.children[1].value = '';
  };

  return (
    <StyledTodoList>
      <StyledTodoListHeader>
        <h3>Todo List</h3>
      </StyledTodoListHeader>
      <div>
        <StyledTodoListSearchWrapper>
          <Input
            startIcon={<i className='fa-solid fa-magnifying-glass'></i>}
            placeholder='Search'
            change={handleSeach}
            ref={inputParentRef}
          />
        </StyledTodoListSearchWrapper>
        <StyledTodoListFiltershWrapper>
          {filters.map((filter) => (
            <FilterItem
              key={filter.title}
              title={filter.title}
              action={setFilterBy}
              active={filter.title === filterBy}
            />
          ))}
        </StyledTodoListFiltershWrapper>
        <div>
          {loading ? (
            <></>
          ) : (
            displyedTodos.map((todo) => (
              <StyledTodoListItemWrapper key={todo.id}>
                <TodoItem data={todo} />
              </StyledTodoListItemWrapper>
            ))
          )}
        </div>
        <StyledTodoListButtonWrapper>
          <Button onClick={handleReset} text='Reset all filters' width='100%' />
        </StyledTodoListButtonWrapper>
      </div>
    </StyledTodoList>
  );
};

export default TodoList;
