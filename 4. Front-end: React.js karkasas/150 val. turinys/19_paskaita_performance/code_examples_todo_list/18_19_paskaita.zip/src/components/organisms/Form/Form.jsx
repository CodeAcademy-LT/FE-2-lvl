import React, { useState, useEffect, useRef } from 'react';
import Button from '../../atoms/Button/Button';
import FormInput from '../../molecules/FormInput';
import { StyledForm } from './Form.style';

const Form = () => {
  // State
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');

  const [formValidationsMessages, setFormValidationsMessages] = useState({
    username: '',
    email: '',
  });

  // Refs
  const usernameInputRef = useRef();
  const emailInputRef = useRef();
  const initialSubmit = useRef(true);

  // Side Effects
  useEffect(() => {
    if (!initialSubmit.current) {
      validateInputs(username, email);
    }
  }, [username, email]);

  const validateInputs = (username, email) => {
    let isUsernameValid;
    let isEmailValid;

    if (username.length < 6) {
      usernameInputRef.current.style.borderColor = 'red';
      isUsernameValid = false;
    } else {
      usernameInputRef.current.style.borderColor = 'green';
      isUsernameValid = true;
    }

    if (!email.includes('@')) {
      emailInputRef.current.style.borderColor = 'red';

      isEmailValid = false;
    } else {
      emailInputRef.current.style.borderColor = 'green';
      isEmailValid = true;
    }

    setFormValidationsMessages({
      username: isUsernameValid
        ? ''
        : 'Username must be at least 6 characters length',
      email: isEmailValid ? '' : 'Email must be email and include @',
    });

    return isUsernameValid && isEmailValid ? true : false;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const isInputsValid = validateInputs(username, email);
    initialSubmit.current = false;

    if (!isInputsValid) {
      return;
    }

    // Other logic if inputs fields are valid....
  };

  return (
    <StyledForm onSubmit={handleSubmit}>
      <FormInput
        name='name'
        text='Name'
        type='text'
        id='name'
        value={name}
        change={setName}
      />
      <FormInput
        name='username'
        text='Username'
        type='text'
        id='username'
        value={username}
        change={setUsername}
        startIcon={<i className='fa-solid fa-user'></i>}
        endIcon={
          formValidationsMessages.username ? (
            <i class='fa-solid fa-xmark'></i>
          ) : (
            <i className='fa-solid fa-check'></i>
          )
        }
        ref={usernameInputRef}
        helperText={formValidationsMessages.username}
      />
      <FormInput
        name='email'
        text='Email'
        type='text'
        id='email'
        value={email}
        change={setEmail}
        startIcon={<i className='fa-solid fa-envelope'></i>}
        endIcon={
          formValidationsMessages.email ? (
            <i class='fa-solid fa-xmark'></i>
          ) : (
            <i className='fa-solid fa-check'></i>
          )
        }
        ref={emailInputRef}
        helperText={formValidationsMessages.email}
      />
      <Button text='Submit' type='submit' />
    </StyledForm>
  );
};

export default Form;
