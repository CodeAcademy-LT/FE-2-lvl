import styled from 'styled-components';

export const StyledTodoList = styled.div`
  max-width: 500px;
  box-shadow: 0px 0px 15px 1px rgba(100, 100, 100, 0.1);
  border-radius: 5px;
`;

export const StyledTodoListHeader = styled.div`
  padding: 15px 20px;
  background-color: #eee;
  border-radius: 5px 5px 0 0;
`;

export const StyledTodoListSearchWrapper = styled.div`
  padding: 7px 12px;
  border-left: 1px solid #eee;
  border-right: 1px solid #eee;
`;

export const StyledTodoListFiltershWrapper = styled.div`
  padding: 10px 12px 0 12px;
  border: 1px solid #eee;
  display: flex;
  justify-content: center;
  gap: 10px;
`;

export const StyledTodoListItemWrapper = styled.div`
  padding: 10px 12px;
  border-right: 1px solid #eee;
  border-bottom: 1px solid #eee;
  border-left: 1px solid #eee;
`;

export const StyledTodoListButtonWrapper = styled.div`
  padding: 7px 12px;
  border-left: 1px solid #eee;
  border-right: 1px solid #eee;
  border-bottom: 1px solid #eee;
  border-radius: 0 0 5px 5px;
`;
