import { forwardRef } from 'react';
import { StyledFilterItem } from './FilterItem.style';

const FilterItem = ({ title, action, active }, ref) => {
  return (
    <StyledFilterItem
      onClick={(e) => action(e.target.innerText)}
      ref={ref}
      active={active}
    >
      {title}
    </StyledFilterItem>
  );
};

export default forwardRef(FilterItem);
