import React from 'react';
import { StyledTodoItem } from './TodoItem.style';

const TodoItem = ({ data: { title, completed } }) => {
  const icon = completed ? (
    <i className='fa-solid fa-circle-check' style={{ color: '#485fc7' }}></i>
  ) : (
    <i className='fa-solid fa-circle-xmark' style={{ color: '#eee' }}></i>
  );
  return (
    <StyledTodoItem>
      {icon}
      {title}
    </StyledTodoItem>
  );
};

export default TodoItem;
