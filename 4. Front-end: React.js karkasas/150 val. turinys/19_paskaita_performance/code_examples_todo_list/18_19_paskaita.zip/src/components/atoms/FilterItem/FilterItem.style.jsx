import styled from 'styled-components';

export const StyledFilterItem = styled.span`
  color: ${(props) => (props.active ? '#333' : '#485fc7')};
  padding-bottom: 10px;
  border-bottom: 1px solid ${(props) => (props.active ? '#333' : '#fff')};

  &:hover {
    cursor: pointer;
    color: #333;
  }
`;
