import styled from 'styled-components';

export const StyledTodoItem = styled.div`
  display: flex;
  gap: 10px;
  color: #333;

  i {
    font-size: 14px;
    align-self: center;
  }
`;
