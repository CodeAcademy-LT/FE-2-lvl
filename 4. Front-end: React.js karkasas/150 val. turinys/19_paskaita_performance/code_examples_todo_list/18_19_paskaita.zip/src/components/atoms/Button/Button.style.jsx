import styled from 'styled-components';

export const StyledButton = styled.button`
  width: ${(props) => (props.width ? props.width : 'auto')};
  background-color: ${(props) => (props.primary ? '#4f4fc4' : '#fff')};
  color: ${(props) => (props.primary ? '#fff' : '#4f4fc4')};
  border-width: 1px;
  border-style: solid;
  border-color: #4f4fc4;
  border-radius: 5px;
  padding: 10px 15px;

  &:hover {
    opacity: 0.9;
    cursor: pointer;
    background-color: ${(props) => (props.primary ? '#4f4fc4' : '#f4f4f4')};
  }
`;
