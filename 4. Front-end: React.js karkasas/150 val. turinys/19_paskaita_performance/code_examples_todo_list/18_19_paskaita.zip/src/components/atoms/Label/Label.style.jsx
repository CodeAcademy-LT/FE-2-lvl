import styled from 'styled-components';

export const StyledLabel = styled.label`
  font-weight: 600;
`;
