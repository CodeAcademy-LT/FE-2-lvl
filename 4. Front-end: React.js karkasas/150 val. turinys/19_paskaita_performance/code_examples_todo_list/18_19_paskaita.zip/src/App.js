import './App.css';
import TodoList from './components/organisms/TodoList';

function App() {
  return (
    <div className='app' style={{ width: '500px', margin: '100px' }}>
      <TodoList />
    </div>
  );
}

export default App;
