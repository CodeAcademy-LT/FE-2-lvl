import ClassCard from './components/class/ClassCard';
import ClassGreeting from './components/class/ClassGreeting';
import FuncCard from './components/function/FuncCard';
import FuncGreeting from './components/function/FuncGreeting';

function App() {
  const name = 'John Smith';

  const generateImage = (index) => {
    const images = [
      'https://images.pexels.com/photos/3244513/pexels-photo-3244513.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/624015/pexels-photo-624015.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/572897/pexels-photo-572897.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    ];

    return images[index];
  };

  return (
    <div>
      <h3>-- Components with static props --</h3>
      <FuncGreeting name={name} />
      <ClassGreeting name={name} />
      <hr />
      <h3>-- Components with dynamic props --</h3>
      <FuncCard generateImage={generateImage} />
      <ClassCard generateImage={generateImage} />
    </div>
  );
}

export default App;
