import React from 'react';

class ClassGreeting extends React.Component {
  render() {
    const { name } = this.props;

    return <h4>Welcome, {name} from ClassGreeting</h4>;
  }
}

export default ClassGreeting;
