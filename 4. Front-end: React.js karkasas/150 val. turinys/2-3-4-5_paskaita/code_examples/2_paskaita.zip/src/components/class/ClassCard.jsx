import React from 'react';

class ClassCard extends React.Component {
  constructor() {
    super();
    this.state = {
      currentImageIndex: 0,
    };
  }

  toogleImage(direction) {
    this.setState((prev) => {
      switch (prev.currentImageIndex) {
        case 0:
          return {
            currentImageIndex: direction === 'prev' ? 2 : 1,
          };
        case 1:
          return {
            currentImageIndex: direction === 'prev' ? 0 : 2,
          };
        case 2:
          return {
            currentImageIndex: direction === 'prev' ? 1 : 0,
          };
      }
    });
  }

  render() {
    const { generateImage } = this.props;

    return (
      <div>
        <h5>ClassCard</h5>
        <img
          src={generateImage(this.state.currentImageIndex)}
          alt='image'
          style={{ width: '200px', display: 'block' }}
        />
        <button onClick={() => this.toogleImage('prev')}>Prev</button>
        <button onClick={() => this.toogleImage('next')}>Next</button>
      </div>
    );
  }
}

export default ClassCard;
