import { useState } from 'react';

const FuncCard = ({ generateImage }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const toggleImage = (direction) => {
    setCurrentImageIndex((prev) => {
      switch (prev) {
        case 0:
          return direction === 'prev' ? 2 : 1;
        case 1:
          return direction === 'prev' ? 0 : 2;
        case 2:
          return direction === 'prev' ? 1 : 0;
      }
    });
  };

  return (
    <div>
      <h5>FuncCard</h5>
      <img
        src={generateImage(currentImageIndex)}
        alt='image'
        style={{ width: '200px', display: 'block' }}
      />
      <button onClick={() => toggleImage('prev')}>Prev</button>
      <button onClick={() => toggleImage('next')}>Next</button>
    </div>
  );
};

export default FuncCard;
