const FuncGreeting = ({ name }) => {
  return <h4>Welcome, {name} from FuncGreeting</h4>;
};

export default FuncGreeting;
