import { Component } from 'react';

class ClassChild extends Component {
  render() {
    console.log('render: ClassChild');
    return <p>Hello, I'm ClassChild</p>;
  }

  componentDidMount() {
    console.log('componentDidMount: ClassChild');
  }

  componentDidUpdate() {
    console.log('componentDidUpdate: ClassChild');
  }

  componentWillUnmount() {
    console.log('componentWillUnmount: ClassChild');
  }
}

export default ClassChild;
