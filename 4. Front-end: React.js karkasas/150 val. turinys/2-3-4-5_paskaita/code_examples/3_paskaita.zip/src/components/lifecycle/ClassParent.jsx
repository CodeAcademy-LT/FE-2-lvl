import { Component } from 'react';
import ClassChild from './ClassChild';

class ClassParent extends Component {
  constructor() {
    super();

    this.state = {
      showChild: true,
    };
  }

  render() {
    console.log('render: ClassParent');
    console.log('render: ClassParent showChild - ' + this.state.showChild);
    return (
      <>
        <h4>Hello I'm ClassParent</h4>
        <button
          onClick={() => this.setState({ showChild: !this.state.showChild })}
        >
          Show/Hide ClassChild
        </button>
        {this.state.showChild && <ClassChild />}
      </>
    );
  }

  componentDidMount() {
    console.log('componentDidMount: ClassParent');
  }

  componentDidUpdate() {
    console.log('componentDidUpdate: ClassParent');
  }
}

export default ClassParent;
