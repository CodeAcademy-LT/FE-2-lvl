import { Component } from 'react';

class ClassMessage extends Component {
  constructor() {
    super();

    this.state = {
      showMessage: true,
      buttonText: 'Hide message',
    };
  }

  render() {
    return (
      <div>
        {this.state.showMessage && <p>Hello World</p>}
        <button
          onClick={() => {
            this.setState((prev) => ({
              showMessage: !prev.showMessage,
              buttonText: prev.showMessage ? 'Show message' : 'Hide message',
            }));
          }}
        >
          {this.state.buttonText}
        </button>
      </div>
    );
  }
}

export default ClassMessage;
