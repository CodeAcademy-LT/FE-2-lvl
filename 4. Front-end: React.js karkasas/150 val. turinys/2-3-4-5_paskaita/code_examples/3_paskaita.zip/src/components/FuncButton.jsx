import PropTypes from 'prop-types';
import './FuncButton.css';

const FuncButton = ({ text, filled, outlined }) => {
  return (
    <button
      className={`func-btn ${
        filled
          ? 'func-btn-filled'
          : outlined
          ? 'func-btn-outlined'
          : 'func-btn-filled'
      }`}
    >
      {text}
    </button>
  );
};

export default FuncButton;

FuncButton.propTypes = {
  text: PropTypes.string.isRequired,
};
