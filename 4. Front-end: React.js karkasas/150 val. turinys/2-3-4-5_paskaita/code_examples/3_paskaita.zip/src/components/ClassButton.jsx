import { Component } from 'react';
import PropTypes from 'prop-types';
import './ClassButton.css';

class ClassButton extends Component {
  render() {
    const { text, size } = this.props;

    let btnSize;
    switch (size) {
      case 1:
        btnSize = 'class-btn-sm';
        break;
      case 2:
        btnSize = 'class-btn-md';
        break;
      case 3:
        btnSize = 'class-btn-lg';
        break;
      default:
        btnSize = 'class-btn-sm';
    }
    return <button className={`class-btn ${btnSize}`}>{text}</button>;
  }
}

export default ClassButton;

ClassButton.propTypes = {
  text: PropTypes.string.isRequired,
  size: PropTypes.oneOf([1, 2, 3]),
};

ClassButton.defaultProps = {
  size: 1,
};
