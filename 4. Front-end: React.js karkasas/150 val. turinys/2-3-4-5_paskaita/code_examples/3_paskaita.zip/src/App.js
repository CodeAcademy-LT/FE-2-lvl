import './App.css';
import ClassButton from './components/ClassButton';
import ClassMessage from './components/ClassMessage';
import FuncButton from './components/FuncButton';
import ClassParent from './components/lifecycle/ClassParent';

function App() {
  return (
    <div className='App'>
      <div>
        <h3>Class Components</h3>
        <ClassButton text={'Class'} size={1} />
        <ClassButton text={'Class'} size={2} />
        <ClassButton text={'Class'} size={3} />
        <ClassButton text={'Class'} size={3} />
        <ClassButton text={'Class'} />

        <ClassMessage />
      </div>
      <hr />
      <div>
        <h3>Function Components</h3>
        <FuncButton text='Function' filled />
        <FuncButton text='Function' outlined />
        <FuncButton text='Function' />
      </div>
      <hr />
      <h2>Component (Class) lifecycle methods</h2>
      <ClassParent />
    </div>
  );
}

export default App;
