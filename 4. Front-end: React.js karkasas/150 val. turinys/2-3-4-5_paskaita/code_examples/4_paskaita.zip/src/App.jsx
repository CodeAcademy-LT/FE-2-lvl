import './App.css';
import { Component } from 'react';
import Login from './components/Login';
import Profile from './components/Profile';

class App extends Component {
  constructor() {
    super();

    this.login = this.login.bind(this);
    this.logout = this.logout.bind(this);

    this.state = {
      isLoggedIn: false,
    };
  }

  login() {
    this.setState({
      isLoggedIn: true,
    });
  }

  logout() {
    this.setState({
      isLoggedIn: false,
    });
  }

  render() {
    const screen = this.state.isLoggedIn ? (
      <Profile logout={this.logout} />
    ) : (
      <Login login={this.login} />
    );

    return (
      <div className='App'>
        <h2>Conditional rendering</h2>
        {screen}
      </div>
    );
  }
}

export default App;
