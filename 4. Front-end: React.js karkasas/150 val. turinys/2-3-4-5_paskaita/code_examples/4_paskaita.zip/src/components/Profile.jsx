import { Component } from 'react';

class Profile extends Component {
  constructor() {
    super();
    this.state = {
      name: '',
    };
  }

  submitName(e) {
    e.preventDefault();
    this.setState({
      name: e.target.name.value,
    });
  }

  render() {
    const { logout } = this.props;
    return (
      <>
        <h4>Profile</h4>
        {this.state.name ? (
          <p>Hello, {this.state.name}</p>
        ) : (
          <form onSubmit={(e) => this.submitName(e)}>
            <input type='text' id='name' />
            <input type='submit' />
          </form>
        )}
        <br />
        <button onClick={() => logout()}>Logout</button>
      </>
    );
  }
}

export default Profile;
