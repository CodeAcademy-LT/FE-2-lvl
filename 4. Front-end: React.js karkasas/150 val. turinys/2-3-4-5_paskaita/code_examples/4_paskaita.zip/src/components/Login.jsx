import { Component } from 'react';

class Login extends Component {
  constructor() {
    super();
  }

  render() {
    const { login } = this.props;
    return (
      <>
        <h4>Login</h4>
        <button onClick={() => login()}>Login</button>
      </>
    );
  }
}

export default Login;
