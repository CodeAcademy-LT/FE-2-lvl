import React, { Suspense } from 'react';
import { Routes, Route } from 'react-router-dom';
// Components
import Header from './components/Header';

import Layout from './Layout';

function App() {
  return (
    <>
      <Header />
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          {Layout.map((route) => (
            <Route key={route.id} path={route.path} element={route.page} />
          ))}
        </Routes>
      </Suspense>
    </>
  );
}

export default App;
