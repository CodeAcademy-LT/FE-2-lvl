import { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Posts = () => {
  // State
  const [posts, setPosts] = useState(null);

  // Side effects
  useEffect(() => {
    (async () => {
      const { data } = await axios.get(
        'https://jsonplaceholder.typicode.com/posts'
      );

      setPosts(data);
    })();
  }, []);

  return (
    <main>
      <h1>Posts</h1>
      {!posts ? (
        <p>Loading...</p>
      ) : (
        <ul>
          {posts.map((post) => (
            <li key={post.id}>
              <Link to={`/posts/${post.id}`}>{post.title}</Link>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
};

export default Posts;
