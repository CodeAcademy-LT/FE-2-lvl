import axios from 'axios';
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const Post = () => {
  // State
  const [post, setPost] = useState(null);

  // React Router
  const { postId } = useParams();
  const navigate = useNavigate();

  // Side effect
  useEffect(() => {
    (async () => {
      const { data } = await axios.get(
        `https://jsonplaceholder.typicode.com/posts/${postId}`
      );

      setPost(data);
    })();
  }, [postId]);

  return (
    <main>
      {!post ? (
        <p>Loading...</p>
      ) : (
        <div>
          <h1>{post.title}</h1>
          <p>{post.body}</p>
          <button onClick={() => navigate(`/posts/${+postId - 1}`)}>
            Previous
          </button>
          <button onClick={() => navigate(`/posts/${+postId + 1}`)}>
            Next
          </button>
        </div>
      )}
    </main>
  );
};

export default Post;
