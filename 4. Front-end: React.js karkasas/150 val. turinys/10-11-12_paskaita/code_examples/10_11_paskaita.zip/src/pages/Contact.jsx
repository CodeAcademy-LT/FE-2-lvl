import React from 'react';

const Contact = () => {
  return (
    <main>
      <h1>Contact</h1>
    </main>
  );
};

export default Contact;
