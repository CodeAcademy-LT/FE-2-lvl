const NotFound = () => {
  return (
    <main>
      <h1>Page Not Found</h1>
    </main>
  );
};

export default NotFound;
