import React from 'react';
// Pages
const Home = React.lazy(() => import('./pages/Home'));
const About = React.lazy(() => import('./pages/About'));
const Posts = React.lazy(() => import('./pages/Posts'));
const Post = React.lazy(() => import('./pages/Post'));
const Contact = React.lazy(() => import('./pages/Contact'));
const NotFound = React.lazy(() => import('./pages/NotFound'));

const Layout = [
  { id: 1, path: '/', page: <Home /> },
  { id: 2, path: 'about', page: <About /> },
  { id: 3, path: 'posts', page: <Posts /> },
  { id: 4, path: 'posts/:postId', page: <Post /> },
  { id: 5, path: 'contact', page: <Contact /> },
  { id: 6, path: '*', page: <NotFound /> },
];

export default Layout;
