import './App.css';
import Counter from './components/Counter';

function App() {
  return (
    <div className='App'>
      <h1>Hello World</h1>
      <Counter step={1} />
      <Counter step={3} />
    </div>
  );
}

export default App;
