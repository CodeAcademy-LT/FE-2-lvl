import { useState } from 'react';

const Counter = ({ step }) => {
  const [count, setCount] = useState(0);

  const increment = () => setCount((prev) => (prev < 10 ? prev + step : prev));
  const decrement = () => setCount((prev) => (prev > 0 ? prev - step : 0));

  return (
    <>
      <h3>Count: {count}</h3>
      <button onClick={increment}>+{step}</button>
      <button onClick={decrement}>-{step}</button>
      {count >= 10 && <p>Max count reached</p>}
    </>
  );
};

export default Counter;
