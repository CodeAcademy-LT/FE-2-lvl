import './App.css';
import Form from './components/organisms/Form';

function App() {
  return (
    <div className='app' style={{ width: '500px' }}>
      <Form />
    </div>
  );
}

export default App;
