import React from 'react';
import { StyledButton } from './Button.style';

const Button = (props) => {
  return (
    <StyledButton onClick={props.action} {...props}>
      {props.text}
    </StyledButton>
  );
};

export default Button;
