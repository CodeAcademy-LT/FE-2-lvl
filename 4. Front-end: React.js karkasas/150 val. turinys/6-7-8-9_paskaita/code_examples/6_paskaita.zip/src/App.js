import './App.css';
import Counter from './components/Counter';
import CounterClass from './components/CounterClass';

function App() {
  return (
    <div className='App'>
      <h2>React Hooks: useState | useEffect</h2>
      <h4>useState</h4>
      <Counter />
      {/* <CounterClass /> */}
    </div>
  );
}

export default App;
