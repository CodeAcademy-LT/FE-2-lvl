import React, { useState, useEffect } from 'react';

const Counter = () => {
  // State
  const [count, setCount] = useState(3);
  const [posts, setPosts] = useState(null);

  // Side effect
  useEffect(() => {
    // Called when component is mountedor it's state or props changed (wthout dep array)
    (async () => {
      const response = await fetch(
        'https://jsonplaceholder.typicode.com/posts/'
      );
      const data = await response.json();

      setPosts(data);
    })();

    return () => {
      // Called when component is unmounted (removed from dom)
    };
  }, []);

  const increment = () => setCount((prev) => prev + 3);

  return (
    <div>
      <button onClick={increment}>Amount: {count}</button>
      {posts &&
        posts.slice(0, count).map((post) => (
          <div key={post.id}>
            <h4>{post.title}</h4>
            <p>{post.body}</p>
          </div>
        ))}
    </div>
  );
};

export default Counter;
