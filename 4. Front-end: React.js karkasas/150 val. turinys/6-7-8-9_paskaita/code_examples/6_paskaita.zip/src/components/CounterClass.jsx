import React, { Component } from 'react';

export class CounterClass extends Component {
  constructor() {
    super();

    this.state = {
      count: 0,
      posts: null,
    };
  }

  increment() {
    this.setState((prev) => ({
      count: prev.count + 1,
    }));
  }

  render() {
    return (
      <div>
        <button onClick={() => this.increment()}>
          (CounterClass) Amount: {this.state.count}
        </button>
        {this.state.posts &&
          this.state.posts.map((post, index) => (
            <div key={post.id}>
              <h5>{post.title}</h5>
              <p>{post.body}</p>
            </div>
          ))}
      </div>
    );
  }

  componentDidMount() {
    (async () => {
      const response = await fetch(
        'https://jsonplaceholder.typicode.com/posts'
      );
      const data = await response.json();

      this.setState({
        count: this.state.count,
        posts: data,
      });
    })();
  }

  componentDidUpdate() {
    // Called when component is updated (changed his state or props)
  }

  componentWillUnmount() {
    // Called when component is unmounted (removed from dom)
  }
}

export default CounterClass;
