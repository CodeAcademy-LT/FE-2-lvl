import React, { useContext } from 'react';
import { CountContext } from '../../App';

const ComponentA = () => {
  const { count } = useContext(CountContext);

  return (
    <div>
      <h2>ComponentA</h2>
      <p>Count from ComponentA: {count}</p>
    </div>
  );
};

export default ComponentA;
