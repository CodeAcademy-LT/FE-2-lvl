import React, { useContext } from 'react';
import { CountContext } from '../../App';

const ComponentF = () => {
  const { count } = useContext(CountContext);

  return (
    <div>
      <h4>ComponentF</h4>
      <p>Count from ComponentF: {count}</p>
    </div>
  );
};

export default ComponentF;
