import React, { useContext } from 'react';
import { CountContext, GreetingContext } from '../../App';

const ComponentD = () => {
  const { setCount } = useContext(CountContext);
  const greeting = useContext(GreetingContext);

  return (
    <div>
      <h3>ComponentD</h3>
      <p>{greeting}</p>
      <button onClick={() => setCount((prev) => prev + 1)}>+ 1</button>
    </div>
  );
};

export default ComponentD;
