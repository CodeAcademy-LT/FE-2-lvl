import React, { useContext } from 'react';
import ComponentE from './ComponentE';
import { GreetingContext } from '../../App';

const ComponentC = () => {
  const greeting = useContext(GreetingContext);
  return (
    <div>
      <h2>ComponentC</h2>
      <p>{greeting}</p>
      <ComponentE />
    </div>
  );
};

export default ComponentC;
