import React from 'react';
import ComponentD from './ComponentD';

const ComponentB = () => {
  return (
    <div>
      <h2>ComponentB</h2>
      <ComponentD />
    </div>
  );
};

export default ComponentB;
