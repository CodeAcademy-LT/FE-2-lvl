import React, { useState, useRef } from 'react';

const Counter = () => {
  const [displayCount, setDisplayCount] = useState(0);

  // using refs as place to store value and after it's change avoiding re-render
  // 1. creating "let count = 0" simulation using useRef
  const countRef = useRef(0);

  const increment = () => {
    // 2. incrementing countRef value without component re-render
    countRef.current = countRef.current += 1;

    if (countRef.current % 10 === 0) {
      setDisplayCount(countRef.current);
    }
  };

  return (
    <div>
      <h3>Count: {displayCount}</h3>
      <button onClick={increment}>+ 1</button>
    </div>
  );
};

export default Counter;
