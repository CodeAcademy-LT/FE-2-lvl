import React, { useRef, useEffect, useState } from 'react';

const Form1 = () => {
  // State
  const [validationMessage, setValidationMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Refs
  // -- using refs to select component (Form) DOM elements
  const nameInputRef = useRef();
  const passwordInputRef = useRef();

  // Side effects
  useEffect(() => {
    nameInputRef.current.focus();
  }, []);

  // Custom funtions
  const formSubmit = (e) => {
    e.preventDefault();

    // - validation
    // ---- name:
    if (!nameInputRef.current.value.length) {
      setValidationMessage('Please enter your name');
      nameInputRef.current.focus();
      return;
    }

    // ---- password:
    if (!passwordInputRef.current.value.length) {
      setValidationMessage('Please enter your password');
      passwordInputRef.current.focus();
      return;
    } else {
      const password = passwordInputRef.current.value.split('');

      const hasNumber = password.some((character) => {
        return typeof +character === 'number' && !isNaN(+character);
      });

      const hasUpperCaseLetter = password.some((character) => {
        return character === character.toUpperCase() && isNaN(+character);
      });

      if (!hasNumber && !hasUpperCaseLetter) {
        setValidationMessage(
          'Password must have at least one uppercase letter and number'
        );
        passwordInputRef.current.focus();
        return;
      } else if (!hasNumber) {
        setValidationMessage('Password must have number');
        passwordInputRef.current.focus();
        return;
      } else if (!hasUpperCaseLetter) {
        setValidationMessage(
          'Password must have at least one uppercase letter'
        );
        passwordInputRef.current.focus();
        return;
      } else {
        if (validationMessage.length) {
          setValidationMessage('');
        }
      }
    }

    // - logic which will be executed when all validation passes
    setSuccessMessage('Form submited');
  };

  return (
    <>
      <form onSubmit={(e) => formSubmit(e)}>
        <div>
          <label htmlFor='name'>Name: </label>
          <input type='text' id='name' ref={nameInputRef} />
        </div>
        <div>
          <label htmlFor='password'>Password: </label>
          <input type='text' id='password' ref={passwordInputRef} />

          <div>{validationMessage && <p>{validationMessage}</p>}</div>

          <div>
            <p>Password requirements</p>
            <ul>
              <li>One upper case letter</li>
              <li>One number</li>
            </ul>
          </div>
        </div>
        <div>
          <button>Submit</button>
        </div>
      </form>
      {successMessage && <p>{successMessage}</p>}
    </>
  );
};

export default Form1;
