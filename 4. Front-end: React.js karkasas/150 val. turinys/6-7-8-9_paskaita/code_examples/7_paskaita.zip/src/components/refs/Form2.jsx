import React, { useRef, useEffect, useState } from 'react';

const Form2 = () => {
  // State
  const [validationMessage, setValidationMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [password, setPassword] = useState('');

  // Refs
  // -- using refs to select component (Form) DOM elements
  const nameInputRef = useRef();
  const passwordInputRef = useRef();

  const hasUpperCaseLiRef = useRef();
  const hasNumberLiRef = useRef();

  const isInitialMount = useRef(true);

  // Side effects
  useEffect(() => {
    if (isInitialMount.current) {
      nameInputRef.current.focus();

      isInitialMount.current = false;
    } else {
      const hasNumber = password.split('').some((character) => {
        return typeof +character === 'number' && !isNaN(+character);
      });

      const hasUpperCaseLetter = password.split('').some((character) => {
        return character === character.toUpperCase() && isNaN(+character);
      });

      if (password.length) {
        if (hasNumber) {
          hasNumberLiRef.current.classList.remove('wrong');
          hasNumberLiRef.current.classList.add('correct');
        } else {
          hasNumberLiRef.current.classList.remove('correct');
          hasNumberLiRef.current.classList.add('wrong');
        }

        if (hasUpperCaseLetter) {
          hasUpperCaseLiRef.current.classList.remove('wrong');
          hasUpperCaseLiRef.current.classList.add('correct');
        } else {
          hasUpperCaseLiRef.current.classList.remove('correct');
          hasUpperCaseLiRef.current.classList.add('wrong');
        }
      }
    }
  }, [password]);

  // Custom funtions
  const formSubmit = (e) => {
    e.preventDefault();

    // - validation
    // ---- name:
    if (!nameInputRef.current.value.length) {
      setValidationMessage('Please enter your name');
      nameInputRef.current.focus();
      return;
    }

    // ---- password:
    if (!passwordInputRef.current.value.length) {
      setValidationMessage('Please enter your password');
      passwordInputRef.current.focus();
      return;
    } else {
      const passwordChatacters = passwordInputRef.current.value.split('');

      const hasNumber = passwordChatacters.some((character) => {
        return typeof +character === 'number' && !isNaN(+character);
      });

      const hasUpperCaseLetter = passwordChatacters.some((character) => {
        return character === character.toUpperCase() && isNaN(+character);
      });

      if (!hasNumber && !hasUpperCaseLetter) {
        setValidationMessage(
          'Password must have at least one uppercase letter and number'
        );
        passwordInputRef.current.focus();
        return;
      } else if (!hasNumber) {
        setValidationMessage('Password must have number');
        passwordInputRef.current.focus();
        return;
      } else if (!hasUpperCaseLetter) {
        setValidationMessage(
          'Password must have at least one uppercase letter'
        );
        passwordInputRef.current.focus();
        return;
      } else {
        if (validationMessage.length) {
          setValidationMessage('');
        }
      }
    }

    // - logic which will be executed when all validation passes
    setSuccessMessage('Form submited');
  };

  return (
    <>
      <form onSubmit={(e) => formSubmit(e)}>
        <div>
          <label htmlFor='name'>Name: </label>
          <input type='text' id='name' ref={nameInputRef} />
        </div>
        <div>
          <label htmlFor='password'>Password: </label>
          <input
            type='text'
            id='password'
            ref={passwordInputRef}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <div>{validationMessage && <p>{validationMessage}</p>}</div>

          <div>
            <p>Password requirements</p>
            <ul>
              <li ref={hasUpperCaseLiRef}>One upper case letter</li>
              <li ref={hasNumberLiRef}>One number</li>
            </ul>
          </div>
        </div>
        <div>
          <button>Submit</button>
        </div>
      </form>
      {successMessage && <p>{successMessage}</p>}
    </>
  );
};

export default Form2;
