import React, { useState, createContext } from 'react';
import './App.css';
import Counter from './components/refs/Counter';
import Form2 from './components/refs/Form2';
// import Form1 from './components/refs/Form1';
import ComponentA from './components/context/ComponentA';
import ComponentB from './components/context/ComponentB';
import ComponentC from './components/context/ComponentC';

export const CountContext = createContext();
export const GreetingContext = createContext();

function App() {
  const [count, setCount] = useState(0);

  return (
    <div className='App'>
      <h2>-- Refs --</h2>
      <Counter />
      <br />
      {/* <Form1 /> */}
      <Form2 />

      <h2>-- Context --</h2>
      <p>Count from App: {count}</p>
      <CountContext.Provider value={{ count, setCount }}>
        <ComponentA />
        <GreetingContext.Provider value={'Hello World'}>
          <ComponentB />
          <ComponentC />
        </GreetingContext.Provider>
      </CountContext.Provider>
    </div>
  );
}

export default App;
