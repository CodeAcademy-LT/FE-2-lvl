import './App.css';
import Users from './components/Users';
// import Numbers from './components/Numbers';

function App() {
  return (
    <div className='App'>
      <h2>Lists and Keys</h2>
      {/* <Numbers /> */}
      <Users />
    </div>
  );
}

export default App;
