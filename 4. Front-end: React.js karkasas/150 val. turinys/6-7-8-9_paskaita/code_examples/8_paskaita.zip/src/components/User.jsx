import React from 'react';

const User = ({ name, email }) => {
  return (
    <div>
      <h4>{name}</h4>
      <p>{email}</p>
    </div>
  );
};

export default User;
