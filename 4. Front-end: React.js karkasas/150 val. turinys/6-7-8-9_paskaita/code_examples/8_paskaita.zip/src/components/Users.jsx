import React, { useState, useEffect } from 'react';
import User from './User';

const Users = () => {
  // State
  const [users, setUsers] = useState(null);
  const [loading, setLoading] = useState(true);

  // Side effects
  useEffect(() => {
    (async () => {
      const response = await fetch(
        'https://jsonplaceholder.typicode.com/users'
      );
      const data = await response.json();

      setUsers(data);
      setLoading(false);
    })();
  }, []);

  return (
    <div>
      <h2>Users</h2>
      {loading ? (
        <p>Loading...</p>
      ) : (
        users.map((user) => (
          <User name={user.name} email={user.email} key={user.id} />
        ))
      )}
    </div>
  );
};

export default Users;
