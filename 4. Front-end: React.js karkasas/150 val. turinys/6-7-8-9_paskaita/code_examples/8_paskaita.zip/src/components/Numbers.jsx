const Numbers = () => {
  const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9];

  const numbersList = numbers.map((number) => {
    return <p key={number}>{number}</p>;
  });

  return (
    <div className='App'>
      <h3>Numbers</h3>
      {numbersList}
    </div>
  );
};

export default Numbers;
