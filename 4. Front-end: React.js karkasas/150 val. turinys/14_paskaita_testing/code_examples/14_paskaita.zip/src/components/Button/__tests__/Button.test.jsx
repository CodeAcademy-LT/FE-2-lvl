import Button from '../Button';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

test('renders Button', () => {
  render(<Button text='Click Me' action={() => null} />);

  const component = screen.getByTestId('Button');

  expect(component).toBeInTheDocument();
});
