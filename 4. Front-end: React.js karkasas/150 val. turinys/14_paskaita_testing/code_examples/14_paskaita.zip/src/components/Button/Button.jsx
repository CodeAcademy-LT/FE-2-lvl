import './Button.css';

const Button = ({ text, action }) => {
  return (
    <button className='btn' onClick={(e) => action(e)} data-testid='Button'>
      {text}
    </button>
  );
};

export default Button;
