import List from '../List';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';

test('renders List', () => {
  render(<List />);

  const componnet = screen.getByTestId('List');

  expect(componnet).toBeInTheDocument();
});

test('display user after one click', () => {
  render(<List />);

  const button = screen.getByText('Display User');

  fireEvent.click(button);

  const list = screen.getByTestId('List');

  expect(list).toHaveTextContent('John Smith');
});

test('display user after one click', () => {
  render(<List />);

  const button = screen.getByTestId('Button');

  fireEvent.click(button);
  fireEvent.click(button);

  const list = screen.getByTestId('List');

  expect(list).not.toHaveTextContent('John Smith');
});
