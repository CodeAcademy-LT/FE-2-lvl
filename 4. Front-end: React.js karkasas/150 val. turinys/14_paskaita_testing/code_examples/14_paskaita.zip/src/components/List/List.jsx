import { useState } from 'react';
import Button from '../Button/Button';

const List = () => {
  const [displayUser, setDisplayUser] = useState(false);
  const handleClick = () => setDisplayUser((prev) => !prev);

  return (
    <div data-testid='List'>
      <Button
        text={displayUser ? 'Hide User' : 'Display User'}
        action={handleClick}
      />
      {displayUser && (
        <ul>
          <li>Name: John Smith</li>
          <li>Age: 85</li>
        </ul>
      )}
    </div>
  );
};

export default List;
