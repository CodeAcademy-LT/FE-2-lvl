import List from './components/List/List';

function App() {
  return (
    <>
      <h1>Hello World</h1>
      <List />
    </>
  );
}

export default App;
