import React from 'react';
import { Link } from 'react-router-dom';

const Product = ({ product }) => {
  return (
    <div style={{ width: 'calc(25% - 10px)' }}>
      <Link to={`/product/${product.id}`}>
        <img src={product.images[0].src} alt={product.name} />
        <h4>{product.name}</h4>
      </Link>
    </div>
  );
};

export default Product;
