import Product from '../Product/Product';
import useProducts from '../../hooks/useProducts';

const Layout = ({ productType, title }) => {
  const { products, loading, error } = useProducts(productType);

  return (
    <main>
      <section>
        <h1>{title}</h1>
      </section>
      <section>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '10px',
          }}
        >
          {loading ? (
            <p>Loading...</p>
          ) : error ? (
            <p>{error}</p>
          ) : (
            products.map((product) => (
              <Product key={product.id} product={product} />
            ))
          )}
        </div>
      </section>
    </main>
  );
};

export default Layout;
