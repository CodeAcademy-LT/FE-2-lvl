import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <header>
      <div>
        <div>PER4MMEDIA</div>
        <nav>
          <ul>
            <li>
              <Link to={'/'}>All products</Link>
            </li>
            <li>
              <Link to={'/apparel'}>Apparel</Link>
            </li>
            <li>
              <Link to={'/calendars'}>Calendars</Link>
            </li>
            <li>
              <Link to={'/cups'}>Cups</Link>
            </li>
            <li>
              <Link to={'/posters'}>Posters</Link>
            </li>
            <li>
              <Link to={'/stickers'}>Stickers</Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
