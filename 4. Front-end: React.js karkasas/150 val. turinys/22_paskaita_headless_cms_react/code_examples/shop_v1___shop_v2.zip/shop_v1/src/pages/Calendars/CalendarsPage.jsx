import Layout from '../../components/Layout/Layout';

const CalendarsPage = () => (
  <Layout productType='calendars' title='Calendars' />
);

export default CalendarsPage;
