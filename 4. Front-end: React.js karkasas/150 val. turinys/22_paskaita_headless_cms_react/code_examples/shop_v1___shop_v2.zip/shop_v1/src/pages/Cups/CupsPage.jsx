import Layout from '../../components/Layout/Layout';

const CupsPage = () => <Layout productType='cups' title='Cups' />;

export default CupsPage;
