import Layout from '../../components/Layout/Layout';

const PostersPage = () => <Layout productType='posters' title='Posters' />;

export default PostersPage;
