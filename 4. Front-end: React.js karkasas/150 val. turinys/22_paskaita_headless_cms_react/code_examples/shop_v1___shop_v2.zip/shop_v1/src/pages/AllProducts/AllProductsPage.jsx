import Layout from '../../components/Layout/Layout';

const AllProductsPage = () => (
  <Layout productType='allProducts' title='All Products' />
);

export default AllProductsPage;
