import Layout from '../../components/Layout/Layout';

const ApparelPage = () => <Layout productType='apparel' title='Apparel' />;

export default ApparelPage;
