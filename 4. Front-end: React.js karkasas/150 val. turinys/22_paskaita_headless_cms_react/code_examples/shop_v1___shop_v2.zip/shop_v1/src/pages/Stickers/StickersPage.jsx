import Layout from '../../components/Layout/Layout';

const StickersPage = () => <Layout productType='stickers' title='Stickers' />;

export default StickersPage;
