import { useParams } from 'react-router-dom';
import useProducts from '../../hooks/useProducts';

const ProductDetailsPage = () => {
  const { id } = useParams();

  const { products, loading, error } = useProducts('singleProduct', id);

  return loading ? (
    <p>Loading...</p>
  ) : error ? (
    <p>{error}</p>
  ) : (
    <main>
      <section>
        <h1>{products.name}</h1>
        <img
          src={products.images[0].src}
          alt={products.name}
          style={{ width: '300px' }}
        />
        <p>Price: {products.price} Eur</p>
      </section>
    </main>
  );
};

export default ProductDetailsPage;
