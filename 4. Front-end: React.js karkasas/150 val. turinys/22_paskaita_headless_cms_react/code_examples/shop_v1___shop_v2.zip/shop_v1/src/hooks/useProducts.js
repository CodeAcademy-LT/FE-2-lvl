import { useState, useEffect } from 'react';
import axios from 'axios';
import useEndpoint from './useEndpoint';

const useProducts = (productType, id) => {
  // State
  const [products, setProducts] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const { consumer_key, consumer_secret, route } = useEndpoint(productType);

  // Side effects
  useEffect(() => {
    (async () => {
      try {
        const { data } = await axios.get(`${id ? route + '/' + id : route}`, {
          headers: {
            Authorization: `Basic ${btoa(
              `${consumer_key}:${consumer_secret}`
            )}`,
          },
        });

        setProducts(data);
        setLoading(false);
      } catch (error) {
        setError(error.message);
        setLoading(false);
      }
    })();
  }, [route, consumer_key, consumer_secret, id]);

  return { products, loading, error };
};

export default useProducts;
