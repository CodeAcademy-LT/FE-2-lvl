const useEndpoint = (productType) => {
  const AUTH_CREDENTIALS = {
    consumer_key: process.env.REACT_APP_CONSUMER_KEY,
    consumer_secret: process.env.REACT_APP_CONSUMER_SECRET,
  };

  const HOST = 'https://per4mmedia.com/';

  switch (productType) {
    case 'allProducts': {
      return {
        ...AUTH_CREDENTIALS,
        route: `${HOST}wp-json/wc/v3/products?per_page=100`,
      };
    }
    case 'apparel': {
      return {
        ...AUTH_CREDENTIALS,
        route: `${HOST}wp-json/wc/v3/products?per_page=100&category=43`,
      };
    }
    case 'calendars': {
      return {
        ...AUTH_CREDENTIALS,
        route: `${HOST}wp-json/wc/v3/products?per_page=100&category=50`,
      };
    }
    case 'cups': {
      return {
        ...AUTH_CREDENTIALS,
        route: `${HOST}wp-json/wc/v3/products?per_page=100&category=45`,
      };
    }
    case 'posters': {
      return {
        ...AUTH_CREDENTIALS,
        route: `${HOST}wp-json/wc/v3/products?per_page=100&category=47`,
      };
    }
    case 'stickers': {
      return {
        ...AUTH_CREDENTIALS,
        route: `${HOST}wp-json/wc/v3/products?per_page=100&category=48`,
      };
    }
    case 'singleProduct': {
      return {
        ...AUTH_CREDENTIALS,
        route: `${HOST}wp-json/wc/v3/products`,
      };
    }

    default: {
      throw new Error("Product type doesn't exists.");
    }
  }
};

export default useEndpoint;
