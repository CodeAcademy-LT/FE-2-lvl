import { lazy, Suspense } from 'react';

import { Routes, Route } from 'react-router-dom';

import Header from './components/Header/Header';

const AllProductsPage = lazy(() =>
  import('./pages/AllProducts/AllProductsPage')
);
const ApparelPage = lazy(() => import('./pages/Apparel/ApparelPage'));
const CalendarsPage = lazy(() => import('./pages/Calendars/CalendarsPage'));
const CupsPage = lazy(() => import('./pages/Cups/CupsPage'));
const PostersPage = lazy(() => import('./pages/Posters/PostersPage'));
const StickersPage = lazy(() => import('./pages/Stickers/StickersPage'));
const ProductDetailsPage = lazy(() =>
  import('./pages/ProductDetails/ProductDetailsPage')
);

function App() {
  return (
    <>
      <Header />
      <Suspense fallback={<p>Loading...</p>}>
        <Routes>
          <Route index element={<AllProductsPage />} />
          <Route path='/apparel' element={<ApparelPage />} />
          <Route path='/calendars' element={<CalendarsPage />} />
          <Route path='/cups' element={<CupsPage />} />
          <Route path='/posters' element={<PostersPage />} />
          <Route path='/stickers' element={<StickersPage />} />
          <Route path='/product/:id' element={<ProductDetailsPage />} />
        </Routes>
      </Suspense>
    </>
  );
}

export default App;
