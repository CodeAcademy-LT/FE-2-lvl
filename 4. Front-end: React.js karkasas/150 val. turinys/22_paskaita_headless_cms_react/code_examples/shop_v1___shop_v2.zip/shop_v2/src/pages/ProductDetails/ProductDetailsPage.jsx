import { useParams } from 'react-router-dom';
import { useContext } from 'react';
import { ProductsContext } from '../../App';

const ProductDetailsPage = () => {
  const { id } = useParams();

  const { state, loading, error } = useContext(ProductsContext);

  const product = state.find((product) => product.id === +id);

  return loading ? (
    <p>Loading...</p>
  ) : error ? (
    <p>{error}</p>
  ) : (
    <main>
      <section>
        <h1>{product.name}</h1>
        <img
          src={product.images[0].src}
          alt={product.name}
          style={{ width: '300px' }}
        />
        <p>Price: {product.price} Eur</p>
      </section>
    </main>
  );
};

export default ProductDetailsPage;
