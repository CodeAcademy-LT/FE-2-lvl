import { lazy, Suspense, useReducer, useEffect, createContext } from 'react';

import { Routes, Route } from 'react-router-dom';

import Header from './components/Header/Header';
import useProducts from './hooks/useProducts';

const AllProductsPage = lazy(() =>
  import('./pages/AllProducts/AllProductsPage')
);
const ApparelPage = lazy(() => import('./pages/Apparel/ApparelPage'));
const CalendarsPage = lazy(() => import('./pages/Calendars/CalendarsPage'));
const CupsPage = lazy(() => import('./pages/Cups/CupsPage'));
const PostersPage = lazy(() => import('./pages/Posters/PostersPage'));
const StickersPage = lazy(() => import('./pages/Stickers/StickersPage'));
const ProductDetailsPage = lazy(() =>
  import('./pages/ProductDetails/ProductDetailsPage')
);

export const ProductsContext = createContext([]);

// Global state
const initialState = [];
const reducer = (state, action) => action.payload;

function App() {
  // state
  const [state, dispatch] = useReducer(reducer, initialState);
  const { products, loading, error } = useProducts('allProducts');

  // side effects
  useEffect(() => {
    dispatch({ payload: products });
  }, [products]);

  return (
    <>
      <ProductsContext.Provider value={{ state, loading, error }}>
        <Header />
        <Suspense fallback={<p>Loading...</p>}>
          <Routes>
            <Route index element={<AllProductsPage />} />
            <Route path='/apparel' element={<ApparelPage />} />
            <Route path='/calendars' element={<CalendarsPage />} />
            <Route path='/cups' element={<CupsPage />} />
            <Route path='/posters' element={<PostersPage />} />
            <Route path='/stickers' element={<StickersPage />} />
            <Route path='/product/:id' element={<ProductDetailsPage />} />
          </Routes>
        </Suspense>
      </ProductsContext.Provider>
    </>
  );
}

export default App;
