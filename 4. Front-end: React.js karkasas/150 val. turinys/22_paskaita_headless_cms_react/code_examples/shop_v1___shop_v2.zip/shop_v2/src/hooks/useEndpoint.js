const useEndpoint = (productType) => {
  const AUTH_CREDENTIALS = {
    consumer_key: process.env.REACT_APP_CONSUMER_KEY,
    consumer_secret: process.env.REACT_APP_CONSUMER_SECRET,
  };

  const HOST = 'https://per4mmedia.com/';

  switch (productType) {
    case 'allProducts': {
      return {
        ...AUTH_CREDENTIALS,
        route: (page) =>
          `${HOST}wp-json/wc/v3/products?per_page=100&page=${page}`,
      };
    }

    default: {
      throw new Error("Product type doesn't exists.");
    }
  }
};

export default useEndpoint;
