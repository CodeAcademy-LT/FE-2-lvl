import { useState, useEffect } from 'react';
import axios from 'axios';
import useEndpoint from './useEndpoint';

const useProducts = (productType, id) => {
  // State
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const { consumer_key, consumer_secret, route } = useEndpoint(productType);

  // Side effects
  useEffect(() => {
    (async () => {
      let page = 1;
      let productsPlaceholder = [];

      const keySecrect = `${consumer_key}:${consumer_secret}`;
      const headers = {
        headers: {
          Authorization: `Basic ${btoa(keySecrect)}`,
        },
      };

      try {
        const { data } = await axios.get(
          `${id ? route(page) + '/' + id : route(page)}`,
          headers
        );

        productsPlaceholder = [...data];

        if (!(productsPlaceholder.length % 100)) {
          while (!(productsPlaceholder.length % 100)) {
            page++;

            const { data } = await axios.get(
              `${id ? route(page) + '/' + id : route(page)}`,
              headers
            );

            productsPlaceholder = [...productsPlaceholder, ...data];
          }
        }

        setProducts(productsPlaceholder);
        setLoading(false);
      } catch (error) {
        setError(error.message);
        setLoading(false);
      }
    })();
  }, [consumer_key, consumer_secret, id]);

  return { products, loading, error };
};

export default useProducts;
