const useProductsFilter = (category, products) => {
  return products.filter((product) => {
    return (
      product.categories.filter((item) => {
        return item.name.toLowerCase() === category;
      }).length > 0
    );
  });
};

export default useProductsFilter;
