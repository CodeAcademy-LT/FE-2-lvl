import { useContext } from 'react';
import Product from '../Product/Product';
import useProductsFilter from '../../hooks/useProductsFilter';
import { ProductsContext } from '../../App';

const Layout = ({ productType, title }) => {
  const { state, loading, error } = useContext(ProductsContext);
  let filteredProducts = useProductsFilter(productType, state);

  if (productType === 'allProducts') {
    filteredProducts = state;
  }

  return (
    <main>
      <section>
        <h1>{title}</h1>
      </section>
      <section>
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '10px',
          }}
        >
          {loading ? (
            <p>Loading...</p>
          ) : error ? (
            <p>{error}</p>
          ) : (
            filteredProducts.map((product) => (
              <Product key={product.id} product={product} />
            ))
          )}
        </div>
      </section>
    </main>
  );
};

export default Layout;
