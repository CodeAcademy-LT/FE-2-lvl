const express = require('express'); // importing express logic from node_modules
const app = express(); // creating app object (with properties and methods) from express returned object. app now is our main application obect which helps create API
const PORT = 5000;

app.use(express.json());

// -- DATABASE simulation
const cars = [
  { id: 1, make: 'Audi' },
  { id: 2, make: 'BMW' },
  { id: 3, make: 'Opel' },
];

// Routes
// -- GET
// --- get all cars | localhos:5000/api/cars
app.get('/api/cars', (req, res) => {
  res.send(cars);
});

// --- get single car based on id | localhos:5000/api/cars/{id}
app.get('/api/cars/:id', (req, res) => {
  const id = +req.params.id;

  const car = cars.find((car) => car.id === id);

  if (!car) res.status(404).send('Car was not found');

  res.send(car);
});

// -- POST
// --- add single car | localhos:5000/api/cars
app.post('/api/cars', (req, res) => {
  const car = { id: cars.length + 1, ...req.body };

  cars.push(car);

  res.send(car);
});

// -- PUT
// --- update single car based on id | localhos:5000/api/cars/{id}
app.put('/api/cars/:id', (req, res) => {
  const id = +req.params.id;
  const newCarMake = req.body.make;

  const car = cars.find((car) => car.id === id);

  if (!car) res.status(404).send('Car was not found');

  car.make = newCarMake;

  res.send(car);
});

// -- DELETE
// --- delete single car based on id | localhos:5000/api/cars/{id}
app.delete('/api/cars/:id', (req, res) => {
  const id = +req.params.id;

  const car = cars.find((car) => car.id === id);

  if (!car) res.status(404).send('Car was not found');

  const carIndex = cars.indexOf(car);
  cars.splice(carIndex, 1);

  res.send('Car deleted');
});

app.listen(PORT, () => console.log(`API is running on PORT:${PORT}`));

/* CRUD (create, read, update, delete)
 ** create  POST    | app.post()
 ** read    GET     | app.get()
 ** update  PUT     | app.put()
 ** delete  DELETE  | app.delete()
 */
