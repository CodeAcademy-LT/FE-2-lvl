const express = require('express');
const mongoose = require('mongoose');

const app = express();
const PORT = 5000;

// Middlewares
app.use(express.json());

// Connecting DB
mongoose
  .connect(
    'mongodb+srv://user_one:labas@cluster0.jzra2.mongodb.net/database_1?retryWrites=true&w=majority'
  )
  .then(() => console.log('Connected to MongoDB!'))
  .catch((e) => console.log(e));

const Post = require('./models/post.model.js'); // Post model is coonected to database_1 / posts -collection

// Routes
app.get('/', (_req, res) => res.send('API is running!'));

app.post('/api/posts', (req, res) => {
  const receivedPostData = req.body;

  // -- validating receivedPostData matches Post model schema
  const post = new Post(receivedPostData);

  // -- saving post to posts collection inside database_1
  post
    .save()
    .then((post) =>
      res.json({
        message: 'Post saved successfully!',
        post,
      })
    )
    .catch((e) => {
      console.log(e);
      res.send('Post save failed!');
    });
});

app.get('/api/posts', async (req, res) => {
  const posts = await Post.find();

  res.json(posts);
});

// Starting server
app.listen(PORT, () => console.log('Server is running!'));
