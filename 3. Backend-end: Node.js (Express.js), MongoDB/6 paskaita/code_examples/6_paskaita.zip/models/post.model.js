const mongoose = require('mongoose');

const postSchema = new mongoose.Schema({
  title: {
    type: String, // String, Number, Date, Buffer, Boolean, Mixed, ObjectId, Array
    required: true,
  },
  body: {
    type: String,
    required: true,
  },
  rating: {
    type: Number,
    required: true,
    default: 0,
  },
  comments: {
    type: Array,
    required: true,
    default: [],
  },
});

const Post = mongoose.model('post', postSchema);
module.exports = Post;
