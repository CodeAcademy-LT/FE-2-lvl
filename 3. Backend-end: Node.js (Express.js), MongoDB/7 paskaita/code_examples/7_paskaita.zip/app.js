const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');

const app = express();
dotenv.config();

// Connecting DB
require('./config/db.js');

const Post = require('./models/post.model.js');

// Middlewares
app.use(express.json());

// Routes
app.get('/', (_req, res) => res.send('API is running.'));

// GET all posts
app.get('/api/posts', async (req, res) => {
  // -- finding all posts from posts collection
  // ---- using promises
  // Post.find()
  //   .then((posts) => res.json(posts))
  //   .catch((e) => console.log(e));

  // --- using async/await
  try {
    const posts = await Post.find();

    res.json(posts);
  } catch (error) {
    console.log(error);
  }
});

// GET sinle post based in id
app.get('/api/posts/:id', async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) res.status(404).json({ message: 'Post not found' });

    res.json(post);
  } catch (error) {
    console.log(error);
  }
});

// POST single post
app.post('/api/posts', async (req, res) => {
  try {
    const data = req.body;

    // -- validating user data if it matches Post model (and postSchema)
    const isDataValid = new Post(data);

    // -- saving validated data to db
    const savedData = await isDataValid.save();

    res.status(201).json(savedData);
  } catch (error) {
    console.log(error);
  }
});

// PUT single post based on id
app.put('/api/posts/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const updateData = req.body;

    await Post.findByIdAndUpdate(id, updateData);
    const updatedPost = await Post.findById(id);

    res.json(updatedPost);
  } catch (error) {
    console.log(error);
  }
});

// DELETE single post based on id
app.delete('/api/posts/:id', async (req, res) => {
  try {
    const id = req.params.id;

    await Post.findByIdAndDelete(id);

    res.json({ message: 'Post deleted' });
  } catch (error) {
    console.log(error);
  }
});

// Starting server
app.listen(
  process.env.PORT,
  console.log(`Server is running on port:${process.env.PORT}`)
);

// ACTIONS with our API using FETCH API
// // GET all
// fetch('http://localhost:5000/api/posts');

// // GET single
// fetch('http://localhost:5000/api/posts/627bed1a5716fefb2dfc66f2');

// // Create single
// fetch('http://localhost:5000/api/posts', {
//   method: PUT,
//   headers: {
//     'Content-type': 'application/json',
//   },
//   body: JSON.stringify({ title: 'Cat', content: 'Cat content...' }),
// });

// // Update single
// fetch('http://localhost:5000/api/posts/627bed1a5716fefb2dfc66f2', {
//   method: PUT,
//   headers: {
//     'Content-type': 'application/json',
//   },
//   body: JSON.stringify({ title: 'Dog' }),
// });

// // Delete single
// fetch('http://localhost:5000/api/posts/627bed1a5716fefb2dfc66f2', {
//   method: DELETE,
// });
