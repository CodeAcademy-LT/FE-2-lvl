const mongoose = require('mongoose');

const connectDB = (async () => {
  try {
    const connection = await mongoose.connect(process.env.MONGODB_URI);

    if (connection) console.log('Conneted to MongoDB');
  } catch (error) {
    console.log(error);
  }
})();

module.exports = connectDB;
